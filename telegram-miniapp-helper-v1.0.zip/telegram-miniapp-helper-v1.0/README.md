### 🎮 Telegram miniapp helper

为您的Cocos游戏无缝接入Web3世界的终极解决方案！

🚀 主要特性

一站式区块链集成

快速接入多链生态系统
零基础实现区块链功能
简化开发流程，专注游戏创作

💪 强大的SDK支持

Telegram Mini App集成

完整支持Telegram Bot API
Mini App专属功能支持
便捷的用户授权管理


TON Network支持

内置TonConnect UI
便捷的钱包连接体验
TON交易功能支持


EVM兼容链支持

WalletConnect集成
多链钱包支持
智能合约交互

🎯 为什么选择我们？

✅ 简单易用

详尽的API文档
完整的示例代码
快速上手指南

✅ 性能优化

轻量级设计
按需加载
低资源占用

✅ 持续更新

定期功能更新
及时的技术支持
活跃的开发者社区